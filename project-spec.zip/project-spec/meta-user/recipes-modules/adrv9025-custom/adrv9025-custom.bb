SUMMARY = "Custom ADRV9025 kernel module"
SECTION = "PETALINUX/modules"
LICENSE = "GPL-2.0-only"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/GPL-2.0-only;md5=801f80980d171dd6425610833a22dbe6"

inherit module

INHIBIT_PACKAGE_STRIP = "1"

SRC_URI = "file://Makefile \
           file://cf_axi_adc.h \
           file://adrv902x \
          "

S = "${WORKDIR}"

# KERNEL_MODULE_AUTOLOAD += "adrv9025_custom"
