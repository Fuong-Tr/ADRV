#ifndef SRC_SI5518_DRVS_H_
#define SRC_SI5518_DRVS_H_

/***************************** Include Files *********************************/


/************************** Constant Definitions *****************************/
/**
 * Command number
 */
#define SI5518_SIO_TEST_CMD						0x01
#define SI5518_SIO_INFO_CMD						0x02
#define SI5518_HOST_LOAD_CMD					0x05
#define SI5518_BOOT_CMD							0x07
#define SI5518_DEVICE_INFO_CMD					0x08
#define SI5518_NVM_STATUS_CMD					0x0a
#define SI5518_RESTART_CMD						0xf0
#define SI5518_APP_INFO_CMD						0x10
#define SI5518_PLL_ACTIVE_INPUT_CLOCK_CMD		0x11
#define SI5518_INPUT_STATUS_CMD					0x12
#define SI5518_PLL_STATUS_CMD					0x13
#define SI5518_INTERRUPT_STATUS_CMD				0x14
#define SI5518_METADATA_CMD						0x15
#define SI5518_REFERENCE_STATUS_CMD				0x16
#define SI5518_PHASE_READOUT_CMD				0x17
#define SI5518_INPUT_PERIOD_READOUT_CMD			0x18
#define SI5518_TEMPERATURE_READOUT_CMD			0x19
#define SI5518_OUTPUTS_AVAILABLE_CMD			0x1a
#define SI5518_PPS_PLL_STATUS_CMD				0x1b
#define SI5518_DCO_READOUT_CMD					0x1d
#define SI5518_FINC_DCO_CMD						0x20
#define SI5518_FDEC_DCO_CMD						0x21
#define SI5518_JESD_SYSREF_PULSER_CMD			0x22
#define SI5518_MANUAL_INPUT_CLOCK_SELECT_CMD	0x23
#define SI5518_VARIABLE_OFFSET_DCO_CMD			0x24
#define SI5518_FORCE_HOLDOVER_CMD				0x25
#define SI5518_PHASE_JAM_SYNC_OUT_CMD			0x26
#define SI5518_PPS_RELOCK_CMD					0x27
#define SI5518_OUTPUT_ENABLE_CMD				0x29
#define SI5518_CLEAR_STATUS_FLAGS_CMD			0x2a
#define SI5518_GLOBAL_SOFT_RESET_CMD			0x2b
#define SI5518_PLL_SOFT_RESET_CMD				0x2c
#define SI5518_OSYNC_REQ_CMD					0x2d
#define SI5518_OUTPUT_PHINC_CMD					0x2e
#define SI5518_OUTPUT_PHDEC_CMD					0x2f

/**
 * Command length
 */
#define SI5518_SIO_TEST_CMD_LEN						0x05		// Can be any length			// CMD + DATA_IN[0] + ... + DATA_IN[M]
#define SI5518_SIO_INFO_CMD_LEN						0x01
#define SI5518_HOST_LOAD_CMD_LEN					0x400       // Must read SIO_INFO for max buffer size
#define SI5518_BOOT_CMD_LEN							0x01
#define SI5518_DEVICE_INFO_CMD_LEN					0x01
#define SI5518_NVM_STATUS_CMD_LEN					0x01
#define SI5518_RESTART_CMD_LEN						0x02
#define SI5518_APP_INFO_CMD_LEN						0x01
#define SI5518_PLL_ACTIVE_INPUT_CLOCK_CMD_LEN		0x02
#define SI5518_INPUT_STATUS_CMD_LEN					0x02
#define SI5518_PLL_STATUS_CMD_LEN					0x02
#define SI5518_INTERRUPT_STATUS_CMD_LEN				0x01
#define SI5518_METADATA_CMD_LEN						0x01
#define SI5518_REFERENCE_STATUS_CMD_LEN				0x01
#define SI5518_PHASE_READOUT_CMD_LEN				0x02
#define SI5518_INPUT_PERIOD_READOUT_CMD_LEN			0x03
#define SI5518_TEMPERATURE_READOUT_CMD_LEN			0x01
#define SI5518_OUTPUTS_AVAILABLE_CMD_LEN			0x01
#define SI5518_PPS_PLL_STATUS_CMD_LEN				0x01
#define SI5518_DCO_READOUT_CMD_LEN					0x02
#define SI5518_FINC_DCO_CMD_LEN						0x01
#define SI5518_FDEC_DCO_CMD_LEN						0x01
#define SI5518_JESD_SYSREF_PULSER_CMD_LEN			0x01
#define SI5518_MANUAL_INPUT_CLOCK_SELECT_CMD_LEN	0x03
#define SI5518_VARIABLE_OFFSET_DCO_CMD_LEN			0x06
#define SI5518_FORCE_HOLDOVER_CMD_LEN				0x03
#define SI5518_PHASE_JAM_SYNC_OUT_CMD_LEN			0x06
#define SI5518_PPS_RELOCK_CMD_LEN					0x01
#define SI5518_OUTPUT_ENABLE_CMD_LEN				0x06
#define SI5518_CLEAR_STATUS_FLAGS_CMD_LEN			0x01
#define SI5518_GLOBAL_SOFT_RESET_CMD_LEN			0x01
#define SI5518_PLL_SOFT_RESET_CMD_LEN				0x03
#define SI5518_OSYNC_REQ_CMD_LEN					0x02
#define SI5518_OUTPUT_PHINC_CMD_LEN					0x04
#define SI5518_OUTPUT_PHDEC_CMD_LEN					0x04

/**
 * Reply length
 */
#define SI5518_SIO_TEST_REP_LEN     				0x06		// SI5518_SIO_TEST_CMD_LEN+1	// STATUS + CMD_ECHO + DATA_IN[0] + ... + DATA_IN[M]
#define SI5518_SIO_INFO_REP_LEN						0x05
#define SI5518_HOST_LOAD_REP_LEN					0x01
#define SI5518_BOOT_REP_LEN							0x01
#define SI5518_DEVICE_INFO_REP_LEN					0x0E
#define SI5518_NVM_STATUS_REP_LEN					0x03
#define SI5518_RESTART_REP_LEN						0x01
#define SI5518_APP_INFO_REP_LEN						0x19
#define SI5518_PLL_ACTIVE_INPUT_CLOCK_REP_LEN		0x02
#define SI5518_INPUT_STATUS_REP_LEN					0x05
#define SI5518_PLL_STATUS_REP_LEN					0x0A
#define SI5518_INTERRUPT_STATUS_REP_LEN				0x09
#define SI5518_METADATA_REP_LEN						0x36
#define SI5518_REFERENCE_STATUS_REP_LEN				0x08
#define SI5518_PHASE_READOUT_REP_LEN				0x13
#define SI5518_INPUT_PERIOD_READOUT_REP_LEN			0x11
#define SI5518_TEMPERATURE_READOUT_REP_LEN			0x05
#define SI5518_OUTPUTS_AVAILABLE_REP_LEN			0x02
#define SI5518_PPS_PLL_STATUS_REP_LEN				0x05
#define SI5518_DCO_READOUT_REP_LEN					0x05
#define SI5518_FINC_DCO_REP_LEN						0x01
#define SI5518_FDEC_DCO_REP_LEN						0x01
#define SI5518_JESD_SYSREF_PULSER_REP_LEN			0x02
#define SI5518_MANUAL_INPUT_CLOCK_SELECT_REP_LEN	0x01
#define SI5518_VARIABLE_OFFSET_DCO_REP_LEN			0x02
#define SI5518_FORCE_HOLDOVER_REP_LEN				0x01
#define SI5518_PHASE_JAM_SYNC_OUT_REP_LEN			0x02
#define SI5518_PPS_RELOCK_REP_LEN					0x01
#define SI5518_OUTPUT_ENABLE_REP_LEN				0x05
#define SI5518_CLEAR_STATUS_FLAGS_REP_LEN			0x01
#define SI5518_GLOBAL_SOFT_RESET_REP_LEN			0x01
#define SI5518_PLL_SOFT_RESET_REP_LEN				0x01
#define SI5518_OSYNC_REQ_REP_LEN					0x02
#define SI5518_OUTPUT_PHINC_REP_LEN					0x02
#define SI5518_OUTPUT_PHDEC_REP_LEN					0x02

/**************************** Type Definitions *******************************/
typedef struct _S_SI5518_FwConfig {
    uint8_t* FwFilePtr;
    long FwFileSize;
    uint8_t* UserFilePtr;
    long UserFileSize;
    uint8_t* PatchFilePtr;
    long PatchFileSize;
} S_SI5518_FwConfig;

/***************** Macros (Inline Functions) Definitions *********************/

/************************** Function Prototypes ******************************/
int SI5518_Init(void);
void SI5518_HardReset(void);
int SI5518_SoftReset(uint8_t u8Mode);
int SI5518_LoadConfig(S_SI5518_FwConfig* sFwConfig);
int SI5518_ReadInfo(void);
int SI5518_GenSysrefPulse(void);

/************************** Variable Definitions *****************************/

#endif