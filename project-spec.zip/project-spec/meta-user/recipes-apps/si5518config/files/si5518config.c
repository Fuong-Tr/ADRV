#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include "si5518config.h"

// /************************** Defines **************************/
#define XST_SUCCESS		0
#define XST_FAILURE		-1

#define SPI_CHIP				"/dev/spidev1.0"
#define SI5518_RESETN_PIN		312+58

// /************************** Variables **************************/
static char FwFileName[64] = "/run/media/BOOT-mmcblk1p1/fwboot1.bin";
static char UserFileName[64] = "/run/media/BOOT-mmcblk1p1/userboot1.bin";
static char PatchFileName[64] = "/run/media/BOOT-mmcblk1p1/patchboot1.bin";
static char IQFileName[64] = "/run/media/BOOT-mmcblk1p1/TM31a.bin";

#define TEST_PATCH_BOOT		1

uint8_t TxBuffer[1024];
uint8_t RxBuffer[128];

int GpioValueFd;
int SpiFd;

// /************************** Functions **************************/
static int LoadSdFile(const char *filename, unsigned char **file_data, long *file_size);
static int SI5518_SpiInit(void);
static int SI5518_GpioInit(void);
static int SI5518_CheckReply(uint8_t* pu8RxBuffer);
static int SI5518_Transfer(uint8_t* pu8TxBuffer, uint16_t CmdLen, uint8_t* pu8RxBuffer, uint16_t RepLen);

// SI5518 command
static int SI5518_SIO_TEST();
static int SI5518_SIO_INFO(uint16_t* p16CmdBufferSize, uint16_t* p16RepBufferSize);
static int SI5518_HOST_LOAD(uint16_t u16CmdBufferSize, uint8_t* pu8FreqPlanData, uint32_t u32FreqPlanLen);
static int SI5518_BOOT();
static int SI5518_RESTART(uint8_t u8Mode);
static int SI5518_DEVICE_INFO();
static int SI5518_APP_INFO();
static int SI5518_INPUT_STATUS(uint8_t u8InputSelect);
static int SI5518_PLL_STATUS(uint8_t u8PllSelect);
static int SI5518_REFERENCE_STATUS();
static int SI5518_JESD_SYSREF_PULSER();

// /************************** Main function **************************/

int main(int argc, char* argv[])
{
	// printf("argc = %d\n", argc);
	// printf("argv[0] = %s\n", argv[0]);
	// printf("argv[1] = %s\n", argv[1]);

	// if (strcmp(argv[1], "on") == 0) {
	//     return -1;
	// }

	/************************************************************
	 * SI5518 Setup
	 ************************************************************/

	int Status;
	S_SI5518_FwConfig sSi5518FwConfig;

	Status = SI5518_Init();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	sSi5518FwConfig.PatchFilePtr = NULL;
	sSi5518FwConfig.PatchFileSize = 0;

	/* Read data from FwFileName in SD to DestinationAddress DDR */
	printf("Read data from SD to DDR\n");
	Status = LoadSdFile(FwFileName, &sSi5518FwConfig.FwFilePtr, &sSi5518FwConfig.FwFileSize);
	if (Status != XST_SUCCESS)
	{
		printf("Error when trying to read data from SD\n");
		return XST_FAILURE;
	}

	printf("sSi5518FwConfig.FwFilePtr = %02x %02x %02x %02x %02x\n", sSi5518FwConfig.FwFilePtr[0], sSi5518FwConfig.FwFilePtr[1], sSi5518FwConfig.FwFilePtr[2], sSi5518FwConfig.FwFilePtr[3], sSi5518FwConfig.FwFilePtr[4]);

	Status = LoadSdFile(UserFileName, &sSi5518FwConfig.UserFilePtr, &sSi5518FwConfig.UserFileSize);
	if (Status != XST_SUCCESS)
	{
		printf("Error when trying to read data from SD\n");
		return XST_FAILURE;
	}

#if(TEST_PATCH_BOOT)
	Status = LoadSdFile(PatchFileName, &sSi5518FwConfig.PatchFilePtr, &sSi5518FwConfig.PatchFileSize);
	if (Status != XST_SUCCESS)
	{
		printf("Error when trying to read data from SD\n");
		return XST_FAILURE;
	}
#endif

	printf("\n\rOld info:\n");
	Status = SI5518_ReadInfo();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	printf("\n\rLoading config ...\n");
	Status = SI5518_LoadConfig(&sSi5518FwConfig);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	printf("\n\rNew info:\n");
	Status = SI5518_ReadInfo();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/************************************************************
	 * SI5518 Setup done
	 ************************************************************/

	free(sSi5518FwConfig.FwFilePtr);
	free(sSi5518FwConfig.UserFilePtr);
	free(sSi5518FwConfig.PatchFilePtr);

	// close(GpioValueFd);

	printf("Closing application ...\n");

	return XST_SUCCESS;
}

//************************** Functions detail **************************/
static int LoadSdFile(const char *filename, unsigned char **file_data, long *file_size)
{
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        perror("Failed to open file");
        return -1;
    }

	// Get file size
    fseek(fp, 0, SEEK_END);
    *file_size = ftell(fp);
    rewind(fp);

	printf("file_size = %ld\n", *file_size);

	// Allocate buffer in DDR (malloc memory comes from DDR in user space)
    unsigned char *buffer = (unsigned char *)malloc(*file_size);
    if (!buffer) {
        perror("Failed to allocate DDR memory");
        fclose(fp);
        return -1;
    }

	// Read file into buffer
    size_t read_bytes = fread(buffer, 1, *file_size, fp);
    if (read_bytes != *file_size) {
        perror("Failed to read full file");
        free(buffer);
        fclose(fp);
        return -1;
    }

	printf("Read %ld bytes from SD card into DDR buffer.\n", *file_size);
	printf("buffer = %02x %02x %02x %02x %02x\n", buffer[0], buffer[1], buffer[2], buffer[3], buffer[4]);

	*file_data = buffer;

	fclose(fp);
	return 0;
}

static int SI5518_GpioInit(void)
{
	int exportfd, directionfd;

	printf("GPIO test running...\n");

	// The GPIO has to be exported to be able to see it in sysfs

	exportfd = open("/sys/class/gpio/export", O_WRONLY);
	if (exportfd < 0)
	{
		printf("Cannot open GPIO to export it\n");
		exit(1);
	}

	write(exportfd, "370", 4);
	close(exportfd);

	printf("GPIO exported successfully\n");

	// Update the direction of the GPIO to be an output

	directionfd = open("/sys/class/gpio/gpio370/direction", O_RDWR);
	if (directionfd < 0)
	{
		printf("Cannot open GPIO direction it\n");
		exit(1);
	}

	write(directionfd, "out", 4);
	close(directionfd);

	printf("GPIO direction set as output successfully\n");

	// Get the GPIO value ready to be toggled

	GpioValueFd = open("/sys/class/gpio/gpio370/value", O_RDWR);
	if (GpioValueFd < 0)
	{
		printf("Cannot open GPIO value\n");
		exit(1);
	}

	printf("GPIO value opened\n");

	return XST_SUCCESS;
}

static int SI5518_SpiInit(void)
{
	const char *device = "/dev/spidev1.0";
	uint32_t bitsPerWord = 8;
	uint32_t speed       = 10000000;
	int result;

	SpiFd = open(device, O_RDWR);
	if (SpiFd < 0) {
		perror("can't open SPI device");
		return XST_FAILURE;
	}

	/*
	* bits per word
	*/
	result = ioctl(SpiFd, SPI_IOC_WR_BITS_PER_WORD, &bitsPerWord);
	if (result < 0)
	{
		/*
		* Error setting the number of Bits per SPI word
		*/
		perror("Error setting the number of Bits per SPI word");
		return XST_FAILURE;
	}

	/*
	* max speed hz
	*/
	result = ioctl(SpiFd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
	if (result < 0)
	{
		/*
		* Error Setting max SPI clock frequency for current chip select index.
		*/
		perror("Error Setting max SPI clock frequency for current chip select index.");
		return XST_FAILURE;
	}

	// close(SpiFd);

	return XST_SUCCESS;
}

int SI5518_Init(void)
{
	int Status;

	Status = SI5518_GpioInit();
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	Status = SI5518_SpiInit();
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}
	
	// Reset SI5518
	SI5518_HardReset();

	Status = SI5518_SIO_TEST();
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}


void SI5518_HardReset(void)
{
    /* Reset and Set SI5518_RSTb = 1 */
	// XGpioPs_WritePin(&GpioInst, SI5518_RESETN_PIN, 0);
	// usleep(100000);
	// XGpioPs_WritePin(&GpioInst, SI5518_RESETN_PIN, 1);
	// usleep(1000000);

	write(GpioValueFd, "0", 2);
	usleep(100000);
	write(GpioValueFd, "1", 2);
	usleep(1000000);
}

/**
*	u8Mode: 0 - Wait for HOST_LOAD commands and/or BOOT command
*			1 - Boot with contents of NVM
*/
int SI5518_SoftReset(uint8_t u8Mode)
{
    int Status;

    Status = SI5518_RESTART(u8Mode);
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    return XST_SUCCESS;
}

int SI5518_LoadConfig(S_SI5518_FwConfig* sFwConfig)
{
    int Status;
	uint16_t u16CmdBufferSize, u16RepBufferSize;

	Status = SI5518_RESTART(0);
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    Status = SI5518_SIO_INFO(&u16CmdBufferSize, &u16RepBufferSize);
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SI5518_HOST_LOAD(u16CmdBufferSize, sFwConfig->FwFilePtr, sFwConfig->FwFileSize);
    if (Status != XST_SUCCESS) {
        printf("[Error] SI5518 load firmware file error\n");
		return XST_FAILURE;
	}

    Status = SI5518_HOST_LOAD(u16CmdBufferSize, sFwConfig->UserFilePtr, sFwConfig->UserFileSize);
    if (Status != XST_SUCCESS) {
        printf("[Error] SI5518 load user file error\n");
		return XST_FAILURE;
	}

    if (sFwConfig->PatchFilePtr != NULL && sFwConfig->PatchFileSize > 0) {
        Status = SI5518_HOST_LOAD(u16CmdBufferSize, sFwConfig->PatchFilePtr, sFwConfig->PatchFileSize);
        if (Status != XST_SUCCESS) {
            printf("[Error] SI5518 load patch file error\n");
		    return XST_FAILURE;
	    }
    }

	Status = SI5518_BOOT();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SI5518_INPUT_STATUS(0x6);
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SI5518_PLL_STATUS(0x1);
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SI5518_REFERENCE_STATUS();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    return XST_SUCCESS;
}

int SI5518_ReadInfo(void)
{
    int Status;

    Status = SI5518_DEVICE_INFO();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    Status = SI5518_APP_INFO();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    return XST_SUCCESS;
}

int SI5518_GenSysrefPulse(void)
{
    int Status;

    Status = SI5518_JESD_SYSREF_PULSER();
    if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

static int SI5518_CheckReply(uint8_t* pu8RxBuffer)
{
	if (pu8RxBuffer[1] == 0x80)
	{
		return XST_SUCCESS;
	} else {
		printf("Reply error status = %02x; Error = 0x%02x%02x\n", pu8RxBuffer[1], pu8RxBuffer[3], pu8RxBuffer[2]);
		return XST_FAILURE;
	}
}

static int SI5518_Transfer(uint8_t* pu8TxBuffer, uint16_t CmdLen, uint8_t* pu8RxBuffer, uint16_t RepLen)
{
	int Status;

	// Status = XSpiPs_PolledTransfer(pu8TxBuffer, NULL, (CmdLen+1));
	// if (Status != XST_SUCCESS) {
	// 	printf("SI5518_SIO_TEST Transfer error\n");
	// 	return XST_FAILURE;
	// }

	struct spi_ioc_transfer SpiTR = {0};

	SpiTR.tx_buf = (unsigned long)pu8TxBuffer;
	SpiTR.rx_buf = (unsigned long)pu8RxBuffer;
	SpiTR.len = CmdLen+1;

	if (ioctl(SpiFd, SPI_IOC_MESSAGE(1), &SpiTR) < 1) {
		perror("Can't send SPI message");
		return XST_FAILURE;
	}

	usleep(50000);

	pu8RxBuffer[0] = 0xD0;

	// Incase we need to check the error in the READ_REPLY
	if(RepLen < 3) {
		RepLen = 3;
	}

	// Status = XSpiPs_PolledTransfer(pu8RxBuffer, pu8RxBuffer, (RepLen+1));
	// if (Status != XST_SUCCESS) {
	// 	printf("SI5518_SIO_TEST Receive error\n");
	// 	return XST_FAILURE;
	// }

	SpiTR.tx_buf = (unsigned long)pu8RxBuffer;
	SpiTR.rx_buf = (unsigned long)pu8RxBuffer;
	SpiTR.len = RepLen+1;

	if (ioctl(SpiFd, SPI_IOC_MESSAGE(1), &SpiTR) < 1) {
		perror("Can't send SPI message");
		return XST_FAILURE;
	}

	Status = SI5518_CheckReply(pu8RxBuffer);
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/************************************ SI5518 Command ************************************/
static int SI5518_SIO_TEST()
{
	int i;
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_SIO_TEST_CMD;
	TxBuffer[2] = 0xAB;
	TxBuffer[3] = 0xCD;
	TxBuffer[4] = 0xEF;
	TxBuffer[5] = 0x89;
 
	Status = SI5518_Transfer(TxBuffer, SI5518_SIO_TEST_CMD_LEN, RxBuffer, SI5518_SIO_TEST_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_SIO_TEST Transfer error\n");
		return XST_FAILURE;
	}
	
	for (i = 2; i < SI5518_SIO_TEST_CMD_LEN+1; i++)	{
		if(TxBuffer[i] != RxBuffer[i+1]) {
			printf("SI5518_SIO_TEST: TxBuffer = %02x; RxBuffer = %02x\n", TxBuffer[i], RxBuffer[i+1]);
			return XST_FAILURE;
		}
	}

	printf("SI5518_SIO_TEST: SUCCESS\n");

	return XST_SUCCESS;
}


static int SI5518_SIO_INFO(uint16_t* p16CmdBufferSize, uint16_t* p16RepBufferSize)
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_SIO_INFO_CMD;

	Status = SI5518_Transfer(TxBuffer, SI5518_SIO_INFO_CMD_LEN, RxBuffer, SI5518_SIO_INFO_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_SIO_INFO Transfer error\n");
		return XST_FAILURE;
	}

	*p16CmdBufferSize = ((uint16_t)RxBuffer[3] << 8) | RxBuffer[2];
	*p16RepBufferSize = ((uint16_t)RxBuffer[5] << 8) | RxBuffer[4];

	printf("CmdBufferSize = %d; RepBufferSize = %d\n", *p16CmdBufferSize, *p16RepBufferSize);

	return XST_SUCCESS;
}

static int SI5518_HOST_LOAD(uint16_t u16CmdBufferSize, uint8_t* pu8FreqPlanData, uint32_t u32FreqPlanLen)
{
	int Status;
	int i;
	uint32_t u32ByteSent = 0;
	// uint16_t u16DataTransferLenMax = u16CmdBufferSize-2; // We send max u16CmdBufferSize-2 data per transfer
	uint16_t u16DataTransferLenMax = 125;
	uint16_t u16DataTransferLen;

	while(u32ByteSent < u32FreqPlanLen) {
		// Calculate data length per transfer
		if (u32ByteSent + u16DataTransferLenMax > u32FreqPlanLen) {
			u16DataTransferLen = u32FreqPlanLen - u32ByteSent;
		} else {
			u16DataTransferLen = u16DataTransferLenMax;
		}
		
		TxBuffer[0] = 0xC0;
		TxBuffer[1] = SI5518_HOST_LOAD_CMD;
		for (i = 0; i < u16DataTransferLen; i++) {
			TxBuffer[i+2] = pu8FreqPlanData[u32ByteSent + i];
		}
		
		Status = SI5518_Transfer(TxBuffer, (u16DataTransferLen + 1), RxBuffer, SI5518_HOST_LOAD_REP_LEN);	// Send u16DataTransferLen and 1 byte CMD
		if (Status != XST_SUCCESS) {
			printf("SI5518_HOST_LOAD Transfer error\n");
			return XST_FAILURE;
		}

		u32ByteSent = u32ByteSent + u16DataTransferLen;

		printf("Sent %d bytes\n", u32ByteSent);
	}

	printf("SI5518_HOST_LOAD: Success\n");

	return XST_SUCCESS;
}

static int SI5518_BOOT()
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_BOOT_CMD;

	Status = SI5518_Transfer(TxBuffer, SI5518_BOOT_CMD_LEN, RxBuffer, SI5518_BOOT_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_BOOT Transfer error\n");
		return XST_FAILURE;
	}

	printf("SI5518_BOOT: Success\n");

	return XST_SUCCESS;
}

/**
*	u8Mode: 0 - Wait for HOST_LOAD commands and/or BOOT command
*			1 - Boot with contents of NVM
*/
static int SI5518_RESTART(uint8_t u8Mode)
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_RESTART_CMD;
	TxBuffer[2] = 0x01 & u8Mode;	

	Status = SI5518_Transfer(TxBuffer, SI5518_RESTART_CMD_LEN, RxBuffer, SI5518_RESTART_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_RESTART Transfer error\n");
		return XST_FAILURE;
	}

	printf("SI5518_RESTART: Success\n");

	return XST_SUCCESS;
}

static int SI5518_DEVICE_INFO()
{
	int Status;
	uint32_t u32Data;
	uint8_t u8Data;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_DEVICE_INFO_CMD;

	Status = SI5518_Transfer(TxBuffer, SI5518_DEVICE_INFO_CMD_LEN, RxBuffer, SI5518_DEVICE_INFO_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_DEVICE_INFO Transfer error\n");
		return XST_FAILURE;
	}

	printf("DEVICE_INFO:\n");
	printf("PartNumber     = %02x%02x\n", RxBuffer[3], RxBuffer[2]);
	printf("DeviceGrade    = %c\n", RxBuffer[4]);
	printf("DeviceRevision = %c\n", RxBuffer[5]);

	u32Data = (((uint32_t)RxBuffer[8] & 0x01) << 16) | ((uint32_t)RxBuffer[7] << 8) | RxBuffer[6];
	if (RxBuffer[8] & 0x3E)	{
		// OPNID First letter
		u8Data = ((RxBuffer[8] & 0x3E) >> 1) + 64;
		printf("OPNID          = %c%d\n", u8Data, u32Data);
	} else {
		printf("OPNID          = %d\n", u32Data);
	}
	
	printf("OPNREV         = %d\n", RxBuffer[10]);
	printf("TempGrade      = 0x%x\n", RxBuffer[11]);
	printf("Package        = 0x%x\n", RxBuffer[12]);
	printf("RomRevision    = 0x%x\n", RxBuffer[14]);

	return XST_SUCCESS;
}

static int SI5518_APP_INFO()
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_APP_INFO_CMD;

	Status = SI5518_Transfer(TxBuffer, SI5518_APP_INFO_CMD_LEN, RxBuffer, SI5518_APP_INFO_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_APP_INFO Transfer error\n");
		return XST_FAILURE;
	}

	printf("SI5518_APP_INFO:\n");
	printf("APP_MAJOR   = %d\n", RxBuffer[2]);
	printf("APP_MINOR   = %d\n", RxBuffer[3]);
	printf("APP_BRANCH  = %d\n", RxBuffer[4]);
	printf("APP_BUILD   = %d\n", ((uint32_t)RxBuffer[6] << 8) | RxBuffer[5]);
	printf("PLANNER_MAJOR   = %d\n", RxBuffer[7]);
	printf("PLANNER_MINOR   = %d\n", RxBuffer[8]);
	printf("PLANNER_BRANCH  = %d\n", RxBuffer[9]);
	printf("PLANNER_BUILD   = %d\n", ((uint32_t)RxBuffer[11] << 8) | RxBuffer[10]);
	printf("DESIGN_ID   = %c%c%c%c%c%c%c%c\n", RxBuffer[12], RxBuffer[13], RxBuffer[14], RxBuffer[15], RxBuffer[16], RxBuffer[17], RxBuffer[18], RxBuffer[19]);
	printf("CBPRO_REV_MAJOR     = %d\n", RxBuffer[20]);
	printf("CBPRO_REV_MINOR     = %d\n", RxBuffer[21]);
	printf("CBPRO_REV_REVISION  = %d\n", RxBuffer[22]);
	printf("CBPRO_REV_SPECIAL   = %d\n", ((uint32_t)RxBuffer[24] << 8) | RxBuffer[23]);
	printf("NVM_BURN  = %d\n", (RxBuffer[25] & 0x02) >> 1);
	printf("PPS_PLL   = %d\n", (RxBuffer[25] & 0x01));

	return XST_SUCCESS;
}

/**
 * u8InputSelect : 0x0 - IN0 - Differential or CMOS input
 *                 0x2 - IN1 - Differential or CMOS input
 *                 0x4 - IN2 - Differential or CMOS input
 *                 0x5 - IN2B - CMOS only input
 *                 0x6 - IN3 - Differential or CMOS input
 *                 0x7 - IN3B - CMOS only input
 */
static int SI5518_INPUT_STATUS(uint8_t u8InputSelect)
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_INPUT_STATUS_CMD;
    TxBuffer[2] = u8InputSelect;

    /* Call this twice to get the latest info */
	Status = SI5518_Transfer(TxBuffer, SI5518_INPUT_STATUS_CMD_LEN, RxBuffer, SI5518_INPUT_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_INPUT_STATUS Transfer error\n");
		return XST_FAILURE;
	}

	Status = SI5518_Transfer(TxBuffer, SI5518_INPUT_STATUS_CMD_LEN, RxBuffer, SI5518_INPUT_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_INPUT_STATUS Transfer error\n");
		return XST_FAILURE;
	}

    printf("SI5518_INPUT_STATUS: Input %d\n", u8InputSelect);

    if (RxBuffer[2] & 0x03) {
        printf("Input clock is invalid: 0x%x\n", RxBuffer[2] & 0x03);
    } else {
        printf("Input clock is valid\n");
    }

    printf("LOSS_OF_SIGNAL_FLAG         = %d\n", RxBuffer[3] & 0x01);
    printf("OUT_OF_FREQUENCY_FLAG       = %d\n", RxBuffer[4] & 0x01);
    printf("PHASE_MONITOR_PHASE_ERROR   = %d\n", (RxBuffer[5] & 0x04) >> 2);
    printf("PHASE_MONITOR_SIGNAL_LATE   = %d\n", (RxBuffer[5] & 0x02) >> 1);
    printf("PHASE_MONITOR_SIGNAL_EARLY  = %d\n", RxBuffer[5] & 0x01);

    return XST_SUCCESS;
}

/**
 * u8PllSelect : 0x1 - Select PLLR
 *               0x2 - Select PLLA
 *               0x4 - Select PLLB
 */
static int SI5518_PLL_STATUS(uint8_t u8PllSelect)
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_PLL_STATUS_CMD;
    TxBuffer[2] = u8PllSelect;

    /* Call this twice to get the latest info */
	Status = SI5518_Transfer(TxBuffer, SI5518_PLL_STATUS_CMD_LEN, RxBuffer, SI5518_PLL_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_PLL_STATUS Transfer error\n");
		return XST_FAILURE;
	}

	Status = SI5518_Transfer(TxBuffer, SI5518_PLL_STATUS_CMD_LEN, RxBuffer, SI5518_PLL_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_PLL_STATUS Transfer error\n");
		return XST_FAILURE;
	}

    printf("SI5518_PLL_STATUS: PLL %d\n", u8PllSelect);
    printf("PLL_OUT_OF_FREQUENCY  = %d\n", (RxBuffer[2] & 0x02) >> 1);
    printf("PLL_OUT_OF_PHASE      = %d\n", (RxBuffer[2] & 0x04) >> 2);
    printf("PLL_LOSS_OF_LOCK      = %d\n", (RxBuffer[2] & 0x10) >> 4);
    printf("PLL_INITIAL_LOCK      = %d\n", (RxBuffer[2] & 0x20) >> 5);

    return XST_SUCCESS;
}

static int SI5518_REFERENCE_STATUS()
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_REFERENCE_STATUS_CMD;

	/* Call this twice to get the latest info */
	Status = SI5518_Transfer(TxBuffer, SI5518_REFERENCE_STATUS_CMD_LEN, RxBuffer, SI5518_REFERENCE_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_REFERENCE_STATUS Transfer error\n");
		return XST_FAILURE;
	}

	Status = SI5518_Transfer(TxBuffer, SI5518_REFERENCE_STATUS_CMD_LEN, RxBuffer, SI5518_REFERENCE_STATUS_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_REFERENCE_STATUS Transfer error\n");
		return XST_FAILURE;
	}

    printf("SI5518_REFERENCE_STATUS:\n");
    if (RxBuffer[2] & 0x03) {
        printf("Reference clock is invalid: 0x%x\n", RxBuffer[2] & 0x03);
    } else {
        printf("Reference clock is valid\n");
    }

    printf("LOSS_OF_SIGNAL_FLAG         = %d\n", RxBuffer[3] & 0x01);
    printf("OUT_OF_FREQUENCY_FLAG       = %d\n", RxBuffer[4] & 0x01);
    printf("PHASE_MONITOR_PHASE_ERROR   = %d\n", (RxBuffer[5] & 0x04) >> 2);
    printf("PHASE_MONITOR_SIGNAL_LATE   = %d\n", (RxBuffer[5] & 0x02) >> 1);
    printf("PHASE_MONITOR_SIGNAL_EARLY  = %d\n", RxBuffer[5] & 0x01);
    printf("LOSS_OF_LOCK_XO             = %d\n", RxBuffer[7] & 0x01);
    printf("FCAL_FAILURE_FLAG           = %d\n", RxBuffer[8] & 0x01);

    return XST_SUCCESS;
}

static int SI5518_JESD_SYSREF_PULSER()
{
	int Status;

	TxBuffer[0] = 0xC0;
	TxBuffer[1] = SI5518_JESD_SYSREF_PULSER_CMD;

	Status = SI5518_Transfer(TxBuffer, SI5518_JESD_SYSREF_PULSER_CMD_LEN, RxBuffer, SI5518_JESD_SYSREF_PULSER_REP_LEN);
	if (Status != XST_SUCCESS) {
		printf("SI5518_JESD_SYSREF_PULSER Transfer error\n");
		return XST_FAILURE;
	}

	if (RxBuffer[2] & 0x01)	{
		printf("Sysref pulses were being generated at the time of the command. The latest request was ignored\n");
		return XST_FAILURE;
	} else {
		printf("Sysref pulses have been generated\n");
	}
	
	return XST_SUCCESS;
}
