#
# This file is the si5518config recipe.
#

SUMMARY = "Simple si5518config application"
SECTION = "PETALINUX/apps"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = "file://si5518config.c \
		file://si5518config.h \
	   	file://Makefile \
		"

S = "${WORKDIR}"

do_compile() {
	     oe_runmake
}

do_install() {
	     install -d ${D}${bindir}
	     install -m 0755 si5518config ${D}${bindir}
}
