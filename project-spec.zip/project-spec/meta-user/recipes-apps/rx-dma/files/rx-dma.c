#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <stdarg.h>

#define SYS_IIO "/sys/bus/iio/devices"
#define MAX_IIO 64
#define BUF_SAMPLES 4096
#define OUT_FILE "capture.txt"

static void path_make(char *out, size_t n, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(out, n, fmt, ap);
    va_end(ap);
}

static int read_text(const char *path, char *buf, size_t n)
{
    int fd = open(path, O_RDONLY);
    if (fd < 0)
        return -1;

    ssize_t r = read(fd, buf, n - 1);
    close(fd);

    if (r < 0)
        return -1;

    buf[r] = 0;

    while (r > 0 &&
          (buf[r - 1] == '\n' || buf[r - 1] == '\r' ||
           buf[r - 1] == ' '  || buf[r - 1] == '\t')) {
        buf[r - 1] = 0;
        r--;
    }

    return 0;
}

static int write_text(const char *path, const char *val)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0)
        return -1;

    ssize_t w = write(fd, val, strlen(val));
    close(fd);

    return w == (ssize_t)strlen(val) ? 0 : -1;
}

static int write_int(const char *path, int val)
{
    char buf[32];
    snprintf(buf, sizeof(buf), "%d", val);
    return write_text(path, buf);
}

static int find_iio_by_name(const char *name)
{
    char path[256];
    char buf[128];

    for (int i = 0; i < MAX_IIO; i++) {
        path_make(path, sizeof(path), SYS_IIO "/iio:device%d/name", i);

        if (read_text(path, buf, sizeof(buf)) == 0) {
            if (strcmp(buf, name) == 0)
                return i;
        }
    }

    return -1;
}

static int parse_rx(const char *s)
{
    if (!s)
        return -1;

    if (!strcasecmp(s, "rx1") || !strcmp(s, "1"))
        return 0;
    if (!strcasecmp(s, "rx2") || !strcmp(s, "2"))
        return 1;
    if (!strcasecmp(s, "rx3") || !strcmp(s, "3"))
        return 2;
    if (!strcasecmp(s, "rx4") || !strcmp(s, "4"))
        return 3;

    return -1;
}

static int disable_all_scan(int adc)
{
    char path[256];

    for (int rx = 0; rx < 4; rx++) {
        path_make(path, sizeof(path),
                  SYS_IIO "/iio:device%d/scan_elements/in_voltage%d_i_en",
                  adc, rx);
        write_int(path, 0);

        path_make(path, sizeof(path),
                  SYS_IIO "/iio:device%d/scan_elements/in_voltage%d_q_en",
                  adc, rx);
        write_int(path, 0);
    }

    return 0;
}

static int enable_rx_scan(int adc, int rx)
{
    char path[256];

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/scan_elements/in_voltage%d_i_en",
              adc, rx);

    if (write_int(path, 1) < 0) {
        fprintf(stderr, "ERROR: cannot enable RX%d I scan\n", rx + 1);
        return -1;
    }

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/scan_elements/in_voltage%d_q_en",
              adc, rx);

    if (write_int(path, 1) < 0) {
        fprintf(stderr, "ERROR: cannot enable RX%d Q scan\n", rx + 1);
        return -1;
    }

    return 0;
}

static void enable_phy_rx(int phy, int rx)
{
    char path[256];

    if (phy < 0)
        return;

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/in_voltage%d_en",
              phy, rx);

    write_int(path, 1);
}

static int16_t le16(const unsigned char *p)
{
    uint16_t u = ((uint16_t)p[0]) | (((uint16_t)p[1]) << 8);
    return (int16_t)u;
}

static void usage(const char *p)
{
    printf("Usage:\n");
    printf("  %s <rx1/rx2/rx3/rx4> <samples>\n", p);
    printf("\n");
    printf("Example:\n");
    printf("  %s rx1 65536\n", p);
}

int main(int argc, char **argv)
{
    int rx;
    long samples_target;
    int adc_dev;
    int phy_dev;

    char path[256];
    char devnode[128];

    int fd_iio = -1;
    FILE *fp = NULL;

    unsigned char buf[BUF_SAMPLES * 4];

    long samples_done = 0;

    double sum_i = 0.0;
    double sum_q = 0.0;
    int peak_i = 0;
    int peak_q = 0;

    if (argc != 3) {
        usage(argv[0]);
        return 1;
    }

    rx = parse_rx(argv[1]);
    if (rx < 0) {
        fprintf(stderr, "ERROR: invalid RX channel: %s\n", argv[1]);
        usage(argv[0]);
        return 1;
    }

    samples_target = atol(argv[2]);
    if (samples_target <= 0) {
        fprintf(stderr, "ERROR: invalid sample count\n");
        return 1;
    }

    adc_dev = find_iio_by_name("ad_ip_jesd204_tpl_adc");
    if (adc_dev < 0) {
        fprintf(stderr, "ERROR: cannot find ad_ip_jesd204_tpl_adc\n");
        return 1;
    }

    phy_dev = find_iio_by_name("adrv9029");

    printf("rx-dma simple capture\n");
    printf("ADC device : iio:device%d\n", adc_dev);
    printf("PHY device : iio:device%d\n", phy_dev);
    printf("RX channel : RX%d\n", rx + 1);
    printf("Samples    : %ld\n", samples_target);
    printf("Output     : %s\n", OUT_FILE);

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/buffer/enable", adc_dev);
    write_int(path, 0);

    disable_all_scan(adc_dev);
    enable_phy_rx(phy_dev, rx);

    if (enable_rx_scan(adc_dev, rx) < 0)
        return 1;

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/buffer/length", adc_dev);
    write_int(path, BUF_SAMPLES);

    fp = fopen(OUT_FILE, "w");
    if (!fp) {
        fprintf(stderr, "ERROR: cannot open %s\n", OUT_FILE);
        return 1;
    }

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/buffer/enable", adc_dev);

    if (write_int(path, 1) < 0) {
        fprintf(stderr, "ERROR: cannot enable ADC buffer\n");
        fclose(fp);
        return 1;
    }

    path_make(devnode, sizeof(devnode), "/dev/iio:device%d", adc_dev);

    fd_iio = open(devnode, O_RDONLY);
    if (fd_iio < 0) {
        fprintf(stderr, "ERROR: cannot open %s: %s\n", devnode, strerror(errno));
        fclose(fp);
        write_int(path, 0);
        return 1;
    }

    printf("Capturing...\n");

    while (samples_done < samples_target) {
        long remain = samples_target - samples_done;
        long want_samples = remain > BUF_SAMPLES ? BUF_SAMPLES : remain;
        size_t want_bytes = want_samples * 4;

        ssize_t r = read(fd_iio, buf, want_bytes);
        if (r < 0) {
            fprintf(stderr, "ERROR: read failed: %s\n", strerror(errno));
            break;
        }

        if (r == 0) {
            fprintf(stderr, "ERROR: read returned 0\n");
            break;
        }

        int got_samples = r / 4;

        for (int n = 0; n < got_samples; n++) {
            int16_t i_val = le16(&buf[n * 4 + 0]);
            int16_t q_val = le16(&buf[n * 4 + 2]);

            fprintf(fp, "%d %d\n", i_val, q_val);

            sum_i += (double)i_val * (double)i_val;
            sum_q += (double)q_val * (double)q_val;

            int ai = i_val < 0 ? -i_val : i_val;
            int aq = q_val < 0 ? -q_val : q_val;

            if (ai > peak_i)
                peak_i = ai;
            if (aq > peak_q)
                peak_q = aq;
        }

        samples_done += got_samples;
    }

    close(fd_iio);
    fclose(fp);

    path_make(path, sizeof(path),
              SYS_IIO "/iio:device%d/buffer/enable", adc_dev);
    write_int(path, 0);

    double rms_i = sqrt(sum_i / samples_done);
    double rms_q = sqrt(sum_q / samples_done);

    double dbfs_i = 20.0 * log10(rms_i / 32768.0 + 1e-15);
    double dbfs_q = 20.0 * log10(rms_q / 32768.0 + 1e-15);

    printf("Done.\n");
    printf("Captured samples: %ld\n", samples_done);
    printf("File            : %s\n", OUT_FILE);
    printf("RX%d_I rms=%.2f peak=%d %.2f dBFS\n", rx + 1, rms_i, peak_i, dbfs_i);
    printf("RX%d_Q rms=%.2f peak=%d %.2f dBFS\n", rx + 1, rms_q, peak_q, dbfs_q);

    return 0;
}