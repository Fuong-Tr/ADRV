#
# This file is the rx-dma recipe.
#

SUMMARY = "Simple rx-dma application"
SECTION = "PETALINUX/apps"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = "file://rx-dma.c \
	   	file://Makefile \
		  "

S = "${WORKDIR}"

do_compile() {
	${CC} ${CFLAGS} ${LDFLAGS} rx-dma.c -o rx-dma -lm
}

do_install() {
	     install -d ${D}${bindir}
	     install -m 0755 rx-dma ${D}${bindir}
}
