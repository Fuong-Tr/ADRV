// SPDX-License-Identifier: MIT
/*
 * dpd-app-auto-orx-window-tx4.c
 * Minimal ADRV9025/ADRV9029 DPD userspace helper for TX4 only.
 *
 * Commands:
 *   dpd-app orx [start_gain_index]
 *   dpd-app run [orx_gain_index]
 *
 * Fixed target:
 *   TX4 = tx3 = mask 0x8
 *   TX4 feedback map = ORX4 = 0x80
 *   Default ORX gain index = 190
 *
 * This app does NOT access SPI directly.
 * It only writes/reads files exported by the kernel driver.
 */

#define _GNU_SOURCE

#include <dirent.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define APP_VERSION "dpd-app minimal-tx4 orx-recommend v4"
#define IIO_BASE "/sys/bus/iio/devices"
#define DEBUGFS_IIO_BASE "/sys/kernel/debug/iio"

#define TX4_MASK 0x8UL
#define TX4_INDEX 3
#define TX4_ORX_MASK 0x80UL
#define DEFAULT_ORX_GAIN 190UL
#define DEFAULT_FAULT_PERCENT 15UL

#define RAW_STATUS_LEN 112
#define DPD_POWER_FULL_SCALE 2147483647.0f
#define ORX_PEAK_WARN_HIGH 1900000000.0f

/* Auto ORX selection thresholds based on observed FW full-scale ~2.147e9. */
#define ORX_SCAN_MIN_INDEX 190UL
#define ORX_SCAN_MAX_INDEX 255UL
#define ORX_SCAN_WINDOW    10UL  /* dpd-app orx 190 => scan 190..200 */
#define ORX_SCAN_STEP      1UL
#define ORX_PEAK_LOW       (0.05f * DPD_POWER_FULL_SCALE)  /* <5%FS: weak */
#define ORX_PEAK_TARGET    (0.25f * DPD_POWER_FULL_SCALE)  /* target ~25%FS */
#define ORX_PEAK_HIGH      (0.70f * DPD_POWER_FULL_SCALE)  /* >70%FS: high */
#define ORX_PEAK_SAT       (0.85f * DPD_POWER_FULL_SCALE)  /* >85%FS: risky */
#define ORX_SAVE_FILE      "/tmp/dpd_tx4_orx_gain"

struct adrv_dev {
	char iio_path[PATH_MAX];
	char dbg_path[PATH_MAX];
	char name[128];
	int index;
};

struct dpd_decoded_status {
	uint32_t dpd_error_code;
	uint32_t percent_complete;
	uint32_t performance_metric;
	uint32_t iter_count;
	uint32_t update_count;
	uint32_t reserved_pm;
	uint32_t reserved_tp;
	uint8_t model_table;
	float mean_tu_power;
	float peak_tu_power;
	float mean_tx_power;
	float peak_tx_power;
	float mean_orx_power;
	float peak_orx_power;
	float direct_evm;
	float indirect_evm;
	float select_error;
	float indirect_error;
	uint16_t err0_metrics;
	uint16_t perr0_metrics;
	uint16_t err1_metrics;
	uint16_t perr1_metrics;
	uint32_t reserved_pr;
	uint16_t err0_actions;
	uint16_t perr0_actions;
	uint16_t err1_actions;
	uint16_t perr1_actions;
	uint32_t sync_status;
};

static void usage(const char *prog)
{
	printf("%s\n", APP_VERSION);
	printf("Usage:\n");
	printf("  %s orx                 # scan 190..200, print one recommended ORX gain\n", prog);
	printf("  %s orx <start_gain>    # scan <start_gain>..<start_gain+10>, step 1\n", prog);
	printf("  %s run <gain_index>    # run DPD using the ORX gain printed by `orx`\n", prog);
	printf("\nFixed target: TX4 / tx3 / mask 0x8 / ORX4 map 0x80\n");
	printf("ORX valid range: %lu..%lu\n", ORX_SCAN_MIN_INDEX, ORX_SCAN_MAX_INDEX);
	printf("ORX scan window: start..start+%lu, step %lu\n", ORX_SCAN_WINDOW, ORX_SCAN_STEP);
	printf("Default ORX start index: %lu\n", DEFAULT_ORX_GAIN);
}

static bool starts_with(const char *s, const char *prefix)
{
	return strncmp(s, prefix, strlen(prefix)) == 0;
}

static bool is_adrv_name(const char *name)
{
	return strcmp(name, "adrv9025") == 0 ||
	       strcmp(name, "adrv9026") == 0 ||
	       strcmp(name, "adrv9029") == 0;
}

static int read_file_trim(const char *path, char *buf, size_t len)
{
	int fd;
	ssize_t n;

	if (!buf || len == 0)
		return -EINVAL;

	fd = open(path, O_RDONLY);
	if (fd < 0)
		return -errno;

	n = read(fd, buf, len - 1);
	if (n < 0) {
		int err = -errno;
		close(fd);
		return err;
	}

	close(fd);
	buf[n] = '\0';

	while (n > 0 &&
	       (buf[n - 1] == '\n' || buf[n - 1] == '\r' ||
		buf[n - 1] == ' ' || buf[n - 1] == '\t')) {
		buf[n - 1] = '\0';
		n--;
	}

	return 0;
}

static int read_file_to_buffer(const char *path, char *buf, size_t len)
{
	int fd;
	ssize_t n;
	size_t off = 0;

	if (!path || !buf || len == 0)
		return -EINVAL;

	fd = open(path, O_RDONLY);
	if (fd < 0)
		return -errno;

	while (off + 1 < len) {
		n = read(fd, buf + off, len - off - 1);
		if (n < 0) {
			int err = -errno;
			close(fd);
			return err;
		}
		if (n == 0)
			break;
		off += (size_t)n;
	}

	close(fd);
	buf[off] = '\0';
	return 0;
}

static int write_file_text(const char *path, const char *text)
{
	int fd;
	ssize_t n;
	size_t len;

	if (!path || !text)
		return -EINVAL;

	len = strlen(text);
	fd = open(path, O_WRONLY);
	if (fd < 0)
		return -errno;

	n = write(fd, text, len);
	if (n < 0) {
		int err = -errno;
		close(fd);
		return err;
	}

	close(fd);
	return ((size_t)n == len) ? 0 : -EIO;
}

static int build_iio_attr_path(struct adrv_dev *dev, const char *attr,
			       char *path, size_t path_len)
{
	int n = snprintf(path, path_len, "%s/%s", dev->iio_path, attr);
	return (n < 0 || (size_t)n >= path_len) ? -ENAMETOOLONG : 0;
}

static int build_dbg_attr_path(struct adrv_dev *dev, const char *attr,
			       char *path, size_t path_len)
{
	int n = snprintf(path, path_len, "%s/%s", dev->dbg_path, attr);
	return (n < 0 || (size_t)n >= path_len) ? -ENAMETOOLONG : 0;
}

static int find_adrv_device(struct adrv_dev *dev)
{
	DIR *dir;
	struct dirent *ent;

	if (!dev)
		return -EINVAL;

	dir = opendir(IIO_BASE);
	if (!dir)
		return -errno;

	while ((ent = readdir(dir)) != NULL) {
		char name_path[PATH_MAX];
		char name[sizeof(dev->name)];
		int idx;
		int ret;

		if (!starts_with(ent->d_name, "iio:device"))
			continue;
		if (sscanf(ent->d_name, "iio:device%d", &idx) != 1)
			continue;

		ret = snprintf(name_path, sizeof(name_path), "%s/%s/name",
			       IIO_BASE, ent->d_name);
		if (ret < 0 || (size_t)ret >= sizeof(name_path))
			continue;

		if (read_file_trim(name_path, name, sizeof(name)) < 0)
			continue;
		if (!is_adrv_name(name))
			continue;

		ret = snprintf(dev->iio_path, sizeof(dev->iio_path), "%s/%s",
			       IIO_BASE, ent->d_name);
		if (ret < 0 || (size_t)ret >= sizeof(dev->iio_path)) {
			closedir(dir);
			return -ENAMETOOLONG;
		}

		ret = snprintf(dev->dbg_path, sizeof(dev->dbg_path), "%s/%s",
			       DEBUGFS_IIO_BASE, ent->d_name);
		if (ret < 0 || (size_t)ret >= sizeof(dev->dbg_path)) {
			closedir(dir);
			return -ENAMETOOLONG;
		}

		strncpy(dev->name, name, sizeof(dev->name) - 1);
		dev->name[sizeof(dev->name) - 1] = '\0';
		dev->index = idx;
		closedir(dir);
		return 0;
	}

	closedir(dir);
	return -ENOENT;
}

static int parse_gain_index(const char *s, unsigned long *index)
{
	char *end = NULL;
	unsigned long v;

	errno = 0;
	v = strtoul(s, &end, 0);
	if (errno || !end || *end != '\0')
		return -EINVAL;
	if (v > 255)
		return -ERANGE;

	*index = v;
	return 0;
}

static int write_iio_one(struct adrv_dev *dev, const char *attr, const char *val)
{
	char path[PATH_MAX];
	int ret = build_iio_attr_path(dev, attr, path, sizeof(path));
	if (ret < 0)
		return ret;
	return write_file_text(path, val);
}

static int read_iio_one(struct adrv_dev *dev, const char *attr, char *buf, size_t len)
{
	char path[PATH_MAX];
	int ret = build_iio_attr_path(dev, attr, path, sizeof(path));
	if (ret < 0)
		return ret;
	return read_file_trim(path, buf, len);
}

static int set_dpd_mask(struct adrv_dev *dev, unsigned long mask)
{
	char val[32];
	snprintf(val, sizeof(val), "0x%lx\n", mask);
	return write_iio_one(dev, "dpd_tx_mask", val);
}

static int dpd_model_config_set(struct adrv_dev *dev, unsigned long mask)
{
	int ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;
	return write_iio_one(dev, "dpd_model_config_set", "1\n");
}

static int dpd_reset(struct adrv_dev *dev, unsigned long mask)
{
	int ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;
	return write_iio_one(dev, "dpd_reset", "1\n");
}

static int dpd_path_delay(struct adrv_dev *dev, unsigned long mask)
{
	int ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;
	return write_iio_one(dev, "calibrate_ext_path_delay_en", "1\n");
}

static int dpd_tracking_config_set(struct adrv_dev *dev, unsigned long mask)
{
	int ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;
	return write_iio_one(dev, "dpd_tracking_config_set", "1\n");
}

static int dpd_tracking_enable(struct adrv_dev *dev, unsigned long mask, bool enable)
{
	int ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;
	return write_iio_one(dev, "dpd_tracking_en", enable ? "1\n" : "0\n");
}

static int dpd_fault_relax(struct adrv_dev *dev, unsigned long mask,
			   unsigned long threshold_percent)
{
	char val[32];
	int ret;

	if (threshold_percent < 1 || threshold_percent > 100)
		return -EINVAL;

	ret = set_dpd_mask(dev, mask);
	if (ret < 0)
		return ret;

	snprintf(val, sizeof(val), "%lu\n", threshold_percent);
	return write_iio_one(dev, "dpd_fault_relax", val);
}

static int dpd_tx_orx_map_set(struct adrv_dev *dev, unsigned long tx_mask,
			      unsigned long orx_mask)
{
	char val[32];
	int ret;

	ret = set_dpd_mask(dev, tx_mask);
	if (ret < 0)
		return ret;

	snprintf(val, sizeof(val), "0x%lx\n", orx_mask);
	ret = write_iio_one(dev, "dpd_tx_orx_map_mask", val);
	if (ret < 0)
		return ret;

	return write_iio_one(dev, "dpd_tx_orx_map", "1\n");
}

static int dpd_orx_gain_set(struct adrv_dev *dev, unsigned long index,
			    unsigned long tx_mask)
{
	char val[32];
	int ret;

	ret = set_dpd_mask(dev, tx_mask);
	if (ret < 0)
		return ret;

	snprintf(val, sizeof(val), "%lu\n", index);
	return write_iio_one(dev, "dpd_orx_gain_index", val);
}

static void disable_orx_user_paths(struct adrv_dev *dev)
{
	/* On this board ORx user paths are exposed as in_voltage4/5.
	 * Ignore errors so the helper remains portable.
	 */
	write_iio_one(dev, "in_voltage4_en", "0\n");
	write_iio_one(dev, "in_voltage5_en", "0\n");
}

static uint16_t dpd_le16(const uint8_t *b, size_t off)
{
	return (uint16_t)((uint16_t)b[off] | ((uint16_t)b[off + 1] << 8));
}

static uint32_t dpd_le32(const uint8_t *b, size_t off)
{
	return (uint32_t)b[off] |
	       ((uint32_t)b[off + 1] << 8) |
	       ((uint32_t)b[off + 2] << 16) |
	       ((uint32_t)b[off + 3] << 24);
}

static float dpd_le_float(const uint8_t *b, size_t off)
{
	uint32_t u = dpd_le32(b, off);
	float f;
	memcpy(&f, &u, sizeof(f));
	return f;
}

static const char *dpd_error_name(uint32_t err)
{
	switch (err) {
	case 0x0000: return "NO_ERROR";
	case 0x3401: return "ORX_ON_DISABLED";
	case 0x3402: return "TX_ON_DISABLED";
	case 0x3403: return "NO_PATHDELAY";
	case 0x3404: return "NO_INIT";
	case 0x3405: return "ORX_SIGNAL_TOO_SMALL";
	case 0x3406: return "ORX_SIGNAL_SATURATING";
	case 0x3407: return "TX_SIGNAL_TOO_SMALL";
	case 0x3408: return "TX_SIGNAL_SATURATING";
	case 0x3409: return "MODELING_ERROR_HIGH";
	case 0x340a: return "AM_AM_OUTLIERS";
	case 0x340b: return "COEFFICIENTS_UNAVAILABLE";
	case 0x340c: return "CAPTURE_LOOP_TIMEOUT";
	case 0x340d: return "UNITY_MODEL_UNAVAILABLE";
	case 0x340e: return "LDL_SOLVER";
	case 0x340f: return "MAX_PARTITIONS_REACHED";
	case 0x3410: return "RPC_FAILED";
	case 0x3411: return "UNKNOWN_RPC";
	case 0x3412: return "MESSAGE_WAIT_TIMEOUT";
	case 0x3413: return "MUTEX_CREATION";
	case 0x3414: return "ACT_I_ASSIGNMENT_CONFLICT";
	case 0x3415: return "ACT_K_ASSIGNMENT_EXCEED_LIMIT";
	case 0x3416: return "ACT_MULTIPLIER_ROW_ASSIGNMENT_CONFLICT";
	case 0x3417: return "ACT_LUT_OUT_OF_RANGE";
	case 0x3418: return "ACT_NO_FREE_MULTIPLIER";
	case 0x3419: return "ADP_WRITE_LUT";
	case 0x341a: return "HARDWARE_IN_USE";
	case 0x341b: return "DATA_CAPTURE";
	case 0x341c: return "DATA_XACC";
	case 0x341d: return "STABILITY";
	case 0x341e: return "CHOL_SOLVER";
	case 0x341f: return "TRACK_CLGC_SYNC";
	case 0x3420: return "ACT_LUT_ENTRY_SAT";
	case 0x3421: return "DATA_CAPTURE_TIMEOUT";
	default: return "UNKNOWN";
	}
}

static int parse_raw_hex_from_status_text(const char *text, uint8_t *raw, size_t raw_len)
{
	const char *p;
	size_t count = 0;

	if (!text || !raw || raw_len == 0)
		return -EINVAL;

	p = strstr(text, "raw_hex:");
	if (!p)
		return -ENOENT;

	p += strlen("raw_hex:");
	while (*p && count < raw_len) {
		char *end = NULL;
		unsigned long v;

		while (*p && isspace((unsigned char)*p))
			p++;
		if (!isxdigit((unsigned char)*p))
			break;

		errno = 0;
		v = strtoul(p, &end, 16);
		if (errno || end == p || v > 0xff)
			return -EINVAL;

		raw[count++] = (uint8_t)v;
		p = end;
	}

	return count == raw_len ? 0 : -EMSGSIZE;
}

static void decode_dpd_status_bytes(const uint8_t raw[RAW_STATUS_LEN],
				    struct dpd_decoded_status *st)
{
	memset(st, 0, sizeof(*st));
	st->dpd_error_code = dpd_le32(raw, 0);
	st->percent_complete = dpd_le32(raw, 4);
	st->performance_metric = dpd_le32(raw, 8);
	st->iter_count = dpd_le32(raw, 12);
	st->update_count = dpd_le32(raw, 16);
	st->reserved_pm = dpd_le32(raw, 36);
	st->reserved_tp = dpd_le32(raw, 40);
	st->model_table = raw[44];
	st->mean_tu_power = dpd_le_float(raw, 48);
	st->peak_tu_power = dpd_le_float(raw, 52);
	st->mean_tx_power = dpd_le_float(raw, 56);
	st->peak_tx_power = dpd_le_float(raw, 60);
	st->mean_orx_power = dpd_le_float(raw, 64);
	st->peak_orx_power = dpd_le_float(raw, 68);
	st->direct_evm = dpd_le_float(raw, 72);
	st->indirect_evm = dpd_le_float(raw, 76);
	st->select_error = dpd_le_float(raw, 80);
	st->indirect_error = dpd_le_float(raw, 84);
	st->err0_metrics = dpd_le16(raw, 88);
	st->perr0_metrics = dpd_le16(raw, 90);
	st->err1_metrics = dpd_le16(raw, 92);
	st->perr1_metrics = dpd_le16(raw, 94);
	st->reserved_pr = dpd_le32(raw, 96);
	st->err0_actions = dpd_le16(raw, 100);
	st->perr0_actions = dpd_le16(raw, 102);
	st->err1_actions = dpd_le16(raw, 104);
	st->perr1_actions = dpd_le16(raw, 106);
	st->sync_status = dpd_le32(raw, 108);
}

static int read_one_status_decoded(struct adrv_dev *dev, int tx_index,
				   struct dpd_decoded_status *st)
{
	char attr[32];
	char path[PATH_MAX];
	char text[16384];
	uint8_t raw[RAW_STATUS_LEN];
	int ret;

	if (!st || tx_index < 0 || tx_index > 3)
		return -EINVAL;

	snprintf(attr, sizeof(attr), "tx%d_dpd_status_raw", tx_index);
	ret = build_dbg_attr_path(dev, attr, path, sizeof(path));
	if (ret < 0)
		return ret;

	ret = read_file_to_buffer(path, text, sizeof(text));
	if (ret < 0)
		return ret;

	ret = parse_raw_hex_from_status_text(text, raw, sizeof(raw));
	if (ret < 0)
		return ret;

	decode_dpd_status_bytes(raw, st);
	return 0;
}

static unsigned long read_tracking_en(struct adrv_dev *dev)
{
	char buf[64];
	if (read_iio_one(dev, "dpd_tracking_en", buf, sizeof(buf)) < 0)
		return 0;
	return strtoul(buf, NULL, 0);
}

static uint16_t all_actions(const struct dpd_decoded_status *st)
{
	return st->err0_actions | st->perr0_actions |
	       st->err1_actions | st->perr1_actions;
}

static void print_minimal_status(const char *title, unsigned long gain,
				 const struct dpd_decoded_status *st,
				 unsigned long tracking_en)
{
	float tx_peak_pct = 100.0f * st->peak_tx_power / DPD_POWER_FULL_SCALE;
	float orx_peak_pct = 100.0f * st->peak_orx_power / DPD_POWER_FULL_SCALE;

	printf("\n%s\n", title);
	printf("target          : TX4/tx3 mask=0x8\n");
	printf("orx_gain_index  : %lu\n", gain);
	printf("tracking_en     : 0x%lx\n", tracking_en);
	printf("error           : 0x%08x (%s)\n",
	       st->dpd_error_code, dpd_error_name(st->dpd_error_code));
	printf("iter/update     : %u/%u\n", st->iter_count, st->update_count);
	printf("tx_peak         : %.9g (%.1f%%FS)\n", st->peak_tx_power, tx_peak_pct);
	printf("orx_peak        : %.9g (%.1f%%FS)\n", st->peak_orx_power, orx_peak_pct);
	printf("evm             : direct=%.2f%% indirect=%.2f%%\n",
	       st->direct_evm * 100.0f, st->indirect_evm * 100.0f);
}

static int dpd_disable_reset(struct adrv_dev *dev)
{
	int ret;

	ret = dpd_tracking_enable(dev, TX4_MASK, false);
	if (ret < 0)
		return ret;
	usleep(100000);

	ret = dpd_reset(dev, TX4_MASK);
	if (ret < 0)
		return ret;
	usleep(300000);

	return 0;
}

static int dpd_start_sequence_tx4(struct adrv_dev *dev, unsigned long gain)
{
	int ret;

	disable_orx_user_paths(dev);

	ret = dpd_disable_reset(dev);
	if (ret < 0)
		return ret;

	ret = dpd_tx_orx_map_set(dev, TX4_MASK, TX4_ORX_MASK);
	if (ret < 0)
		return ret;

	ret = dpd_model_config_set(dev, TX4_MASK);
	if (ret < 0)
		return ret;

	ret = dpd_orx_gain_set(dev, gain, TX4_MASK);
	if (ret < 0)
		return ret;

	ret = dpd_reset(dev, TX4_MASK);
	if (ret < 0)
		return ret;
	usleep(300000);

	ret = dpd_path_delay(dev, TX4_MASK);
	if (ret < 0)
		return ret;
	usleep(500000);

	/* Keep same default behavior as previous app's ORX/run path. */
	ret = dpd_fault_relax(dev, TX4_MASK, DEFAULT_FAULT_PERCENT);
	if (ret < 0)
		return ret;

	ret = dpd_tracking_config_set(dev, TX4_MASK);
	if (ret < 0)
		return ret;
	usleep(300000);

	ret = dpd_tracking_enable(dev, TX4_MASK, true);
	if (ret < 0)
		return ret;

	return 0;
}

static int poll_status_tx4(struct adrv_dev *dev, struct dpd_decoded_status *best)
{
	struct dpd_decoded_status st;
	bool have = false;
	int ret;
	int i;

	memset(best, 0, sizeof(*best));

	for (i = 0; i < 5; i++) {
		sleep(i == 0 ? 2 : 1);
		ret = read_one_status_decoded(dev, TX4_INDEX, &st);
		if (ret < 0)
			continue;

		if (!have || st.update_count >= best->update_count)
			*best = st;
		have = true;

		if (st.dpd_error_code != 0)
			break;
		if (st.update_count > 0)
			break;
	}

	return have ? 0 : -EIO;
}

static const char *orx_result_name(const struct dpd_decoded_status *st)
{
	if (st->dpd_error_code == 0x3406 || st->peak_orx_power >= ORX_PEAK_SAT)
		return "ORX_FAIL_HIGH";
	if (st->dpd_error_code == 0x3405 || st->peak_orx_power < ORX_PEAK_LOW)
		return "ORX_FAIL_LOW";
	return "ORX_OK";
}

static bool orx_candidate_usable(const struct dpd_decoded_status *st)
{
	return strcmp(orx_result_name(st), "ORX_OK") == 0;
}

static double abs_double(double x)
{
	return x < 0.0 ? -x : x;
}

static double orx_candidate_score(const struct dpd_decoded_status *st)
{
	double score;
	double peak = (double)st->peak_orx_power;

	if (!orx_candidate_usable(st))
		return -1.0e99;

	/* Main target: keep ORX feedback away from noise floor and clipping.
	 * A peak around 25%%FS is a good practical starting point.
	 */
	score = 1000000.0 - abs_double(peak - ORX_PEAK_TARGET) / 1000.0;

	/* Prefer FW states that already accept updates, but do not require this
	 * during ORX selection because TX_SIGNAL_SATURATING can be a TX-data issue.
	 */
	if (st->dpd_error_code == 0)
		score += 100000.0;
	if (st->update_count > 0)
		score += 50000.0;
	if (st->dpd_error_code == 0x3408) /* TX_SIGNAL_SATURATING */
		score -= 10000.0;

	/* Avoid ORX levels that are usable but already high. */
	if (peak > ORX_PEAK_HIGH)
		score -= (peak - ORX_PEAK_HIGH) / 1000.0;

	return score;
}

static int save_orx_gain(unsigned long gain)
{
	char val[32];
	snprintf(val, sizeof(val), "%lu\n", gain);
	return write_file_text(ORX_SAVE_FILE, val);
}

static int load_orx_gain(unsigned long *gain)
{
	char buf[64];
	char *end = NULL;
	unsigned long v;

	if (!gain)
		return -EINVAL;

	if (read_file_trim(ORX_SAVE_FILE, buf, sizeof(buf)) < 0)
		return -ENOENT;

	errno = 0;
	v = strtoul(buf, &end, 0);
	if (errno || !end || *end != '\0' || v > 255)
		return -EINVAL;

	*gain = v;
	return 0;
}

static int probe_orx_gain(struct adrv_dev *dev, unsigned long gain,
				  struct dpd_decoded_status *st,
				  unsigned long *tracking_en)
{
	int ret;

	ret = dpd_start_sequence_tx4(dev, gain);
	if (ret < 0)
		return ret;

	ret = poll_status_tx4(dev, st);
	if (tracking_en)
		*tracking_en = read_tracking_en(dev);

	/* Every ORX probe is temporary. Never leave probe DPD active. */
	dpd_disable_reset(dev);
	return ret;
}

static void print_orx_scan_line(unsigned long gain,
					const struct dpd_decoded_status *st)
{
	float tx_peak_pct = 100.0f * st->peak_tx_power / DPD_POWER_FULL_SCALE;
	float orx_peak_pct = 100.0f * st->peak_orx_power / DPD_POWER_FULL_SCALE;

	printf("gain=%3lu  orx=%6.1f%%FS  tx=%6.1f%%FS  err=0x%08x %-22s  upd=%u  %s\n",
	       gain,
	       orx_peak_pct,
	       tx_peak_pct,
	       st->dpd_error_code,
	       dpd_error_name(st->dpd_error_code),
	       st->update_count,
	       orx_result_name(st));
}

static int cmd_orx_single(struct adrv_dev *dev, unsigned long gain)
{
	struct dpd_decoded_status st;
	unsigned long tracking_en = 0;
	const char *orx_result;
	int ret;

	ret = probe_orx_gain(dev, gain, &st, &tracking_en);
	if (ret < 0) {
		fprintf(stderr, "RESULT          : ORX_FAIL\n");
		fprintf(stderr, "REASON          : probe_error: %s\n", strerror(-ret));
		return 1;
	}

	print_minimal_status("DPD TX4 ORX CHECK", gain, &st, tracking_en);
	orx_result = orx_result_name(&st);
	printf("ORX_RESULT      : %s\n", orx_result);
	printf("DPD_UPDATE      : %s\n", (st.update_count > 0 && st.dpd_error_code == 0) ? "YES" : "NO");

	if (strcmp(orx_result, "ORX_OK") == 0) {
		save_orx_gain(gain);
		printf("SELECTED_ORX    : %lu\n", gain);
		printf("SAVED_TO        : %s\n", ORX_SAVE_FILE);
		return 0;
	}

	return 1;
}

static int cmd_orx_window(struct adrv_dev *dev, unsigned long start_gain)
{
	struct dpd_decoded_status st;
	struct dpd_decoded_status best_st;
	unsigned long best_gain = 0;
	unsigned long end_gain;
	double best_score = -1.0e99;
	bool have_best = false;
	bool saw_tx_saturating = false;
	bool saw_orx_high = false;
	bool saw_orx_low = false;
	unsigned long gain;
	int ret;

	if (start_gain < ORX_SCAN_MIN_INDEX || start_gain > ORX_SCAN_MAX_INDEX) {
		fprintf(stderr, "Invalid ORX start gain. Valid range is %lu..%lu.\n",
			ORX_SCAN_MIN_INDEX, ORX_SCAN_MAX_INDEX);
		return 1;
	}

	end_gain = start_gain + ORX_SCAN_WINDOW;
	if (end_gain > ORX_SCAN_MAX_INDEX)
		end_gain = ORX_SCAN_MAX_INDEX;

	printf("\nDPD TX4 ORX WINDOW SCAN\n");
	printf("target          : TX4/tx3 mask=0x8\n");
	printf("scan_range      : %lu..%lu step %lu\n",
	       start_gain, end_gain, ORX_SCAN_STEP);
	printf("target_orx_peak : %.1f%%FS\n", 100.0f * ORX_PEAK_TARGET / DPD_POWER_FULL_SCALE);
	printf("good_orx_region : %.1f%%FS .. %.1f%%FS\n\n",
	       100.0f * ORX_PEAK_LOW / DPD_POWER_FULL_SCALE,
	       100.0f * ORX_PEAK_SAT / DPD_POWER_FULL_SCALE);

	for (gain = start_gain; gain <= end_gain; gain += ORX_SCAN_STEP) {
		double score;
		const char *orx_name;

		memset(&st, 0, sizeof(st));
		ret = probe_orx_gain(dev, gain, &st, NULL);
		if (ret < 0) {
			printf("gain=%3lu  probe_error: %s\n", gain, strerror(-ret));
			continue;
		}

		print_orx_scan_line(gain, &st);

		orx_name = orx_result_name(&st);
		if (strcmp(orx_name, "ORX_FAIL_HIGH") == 0)
			saw_orx_high = true;
		else if (strcmp(orx_name, "ORX_FAIL_LOW") == 0)
			saw_orx_low = true;

		if (st.dpd_error_code == 0x3408)
			saw_tx_saturating = true;

		/* Only select from ORX_OK candidates.  A high score from a bad ORX
		 * candidate must not overwrite a previously good ORX candidate.
		 */
		if (!orx_candidate_usable(&st))
			continue;

		score = orx_candidate_score(&st);
		if (!have_best || score > best_score) {
			have_best = true;
			best_score = score;
			best_gain = gain;
			best_st = st;
		}
	}

	if (!have_best) {
		printf("\nRESULT          : ORX_AUTO_FAIL\n");
		printf("REASON          : no ORX_OK candidate in %lu..%lu\n",
		       start_gain, end_gain);
		if (saw_orx_low)
			printf("HINT            : ORX too low in this window; try `dpd-app orx %lu`\n",
			       end_gain < ORX_SCAN_MAX_INDEX ? end_gain + 1 : end_gain);
		if (saw_orx_high)
			printf("HINT            : ORX too high in this window; try lower start gain\n");
		if (saw_tx_saturating)
			printf("NOTE            : TX is saturating; ORX can still be checked, but DPD run will fail until TX peak is below full-scale.\n");
		return 1;
	}

	/* Save is optional convenience only.  The intended next step is still:
	 *   dpd-app run <RECOMMENDED_ORX_GAIN>
	 */
	save_orx_gain(best_gain);

	printf("\nRESULT                  : ORX_RECOMMENDED\n");
	printf("RECOMMENDED_ORX_GAIN    : %lu\n", best_gain);
	printf("RUN_COMMAND             : dpd-app run %lu\n", best_gain);
	printf("recommended_orx_peak    : %.9g (%.1f%%FS)\n",
	       best_st.peak_orx_power,
	       100.0f * best_st.peak_orx_power / DPD_POWER_FULL_SCALE);
	printf("recommended_tx_peak     : %.9g (%.1f%%FS)\n",
	       best_st.peak_tx_power,
	       100.0f * best_st.peak_tx_power / DPD_POWER_FULL_SCALE);
	printf("recommended_status      : err=0x%08x (%s), update=%u\n",
	       best_st.dpd_error_code, dpd_error_name(best_st.dpd_error_code), best_st.update_count);
	printf("saved_to                : %s\n", ORX_SAVE_FILE);

	if (best_st.dpd_error_code == 0x3408) {
		printf("NOTE                    : ORX gain is reasonable, but TX_SIGNAL_SATURATING remains. `run` will fail until TX peak is below full-scale.\n");
	} else if (best_st.dpd_error_code == 0 && best_st.update_count > 0) {
		printf("NOTE                    : This candidate already accepted a DPD update during probe. Run it again with the command above to keep DPD enabled.\n");
	}

	return 0;
}

static int cmd_run(struct adrv_dev *dev, unsigned long gain)
{
	struct dpd_decoded_status st;
	unsigned long tracking_en;
	bool pass;
	int ret;

	ret = dpd_start_sequence_tx4(dev, gain);
	if (ret < 0) {
		fprintf(stderr, "RESULT          : DPD_FAIL\n");
		fprintf(stderr, "REASON          : sequence_error at sysfs write: %s\n", strerror(-ret));
		dpd_disable_reset(dev);
		return 1;
	}

	ret = poll_status_tx4(dev, &st);
	tracking_en = read_tracking_en(dev);
	if (ret < 0) {
		fprintf(stderr, "RESULT          : DPD_FAIL\n");
		fprintf(stderr, "REASON          : cannot read tx3_dpd_status_raw\n");
		dpd_disable_reset(dev);
		return 1;
	}

	print_minimal_status("DPD TX4 RUN", gain, &st, tracking_en);

	pass = (st.dpd_error_code == 0 &&
		(st.update_count > 0) &&
		(tracking_en & TX4_MASK) &&
		!(all_actions(&st) & 0x0001));

	if (pass) {
		printf("RESULT          : DPD_ENABLED\n");
		printf("REASON          : NO_ERROR + update_count>0\n");
		return 0;
	}

	printf("RESULT          : DPD_FAIL\n");	
	if (st.dpd_error_code != 0)
		printf("REASON          : %s\n", dpd_error_name(st.dpd_error_code));
	else if (st.update_count == 0)
		printf("REASON          : NO_UPDATE\n");
	else if (all_actions(&st) & 0x0001)
		printf("REASON          : FW_SKIP_LUT_UPDATE\n");
	else
		printf("REASON          : NOT_ENABLED\n");

	/* Do not leave a failed/bad DPD state active. */
	dpd_disable_reset(dev);
	return 1;
}

int main(int argc, char **argv)
{
	struct adrv_dev dev;
	unsigned long gain = DEFAULT_ORX_GAIN;
	bool has_gain_arg = false;
	int ret;

	if (argc < 2) {
		usage(argv[0]);
		return 1;
	}

	if (argc >= 3) {
		ret = parse_gain_index(argv[2], &gain);
		if (ret < 0) {
			fprintf(stderr, "Invalid ORX gain index. Use 0..255.\n");
			return 1;
		}
		has_gain_arg = true;
	}

	ret = find_adrv_device(&dev);
	if (ret < 0) {
		fprintf(stderr, "ERROR: cannot find ADRV9025/9026/9029 IIO device: %s\n", strerror(-ret));
		return 1;
	}

	printf("Using %s: name=%s\n", dev.iio_path, dev.name);
	printf("App version: %s\n", APP_VERSION);

	if (strcmp(argv[1], "orx") == 0) {
		/* dpd-app orx 190 scans 190..200 and prints one recommended ORX gain. */
		return cmd_orx_window(&dev, has_gain_arg ? gain : DEFAULT_ORX_GAIN);
	}

	if (strcmp(argv[1], "run") == 0) {
		if (!has_gain_arg) {
			if (load_orx_gain(&gain) == 0)
				printf("Using saved ORX gain index: %lu\n", gain);
			else
				printf("No saved ORX gain. Using default: %lu\n", gain);
		}
		return cmd_run(&dev, gain);
	}

	usage(argv[0]);
	return 1;
}