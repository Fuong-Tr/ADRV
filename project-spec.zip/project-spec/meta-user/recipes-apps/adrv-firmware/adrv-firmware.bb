SUMMARY = "Simple adrv-firmware application"
SECTION = "PETALINUX/apps"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = " \
    file://ActiveUseCase.profile \
    file://ActiveUtilInit.profile \
    file://ADRV9025_FW.bin \
    file://ADRV9025_DPDCORE_FW.bin \
    file://stream_image.bin \
    file://RxGainTable.csv \
    file://TxAttenTable.csv \
    file://stream_options_6E3E00EFB74FE7D465FA88A171B81B8F.txt \
    file://adrv-firmware.sh \
"

S = "${WORKDIR}"


do_compile[noexec] = "1"

do_install() {

    install -d ${D}/lib/firmware

    install -m 0644 ${S}/ActiveUseCase.profile ${D}/lib/firmware/
    install -m 0644 ${S}/ActiveUtilInit.profile ${D}/lib/firmware/
    install -m 0644 ${S}/ADRV9025_FW.bin ${D}/lib/firmware/
    install -m 0644 ${S}/ADRV9025_DPDCORE_FW.bin ${D}/lib/firmware/
    install -m 0644 ${S}/stream_image.bin ${D}/lib/firmware/
    install -m 0644 ${S}/RxGainTable.csv ${D}/lib/firmware/
    install -m 0644 ${S}/TxAttenTable.csv ${D}/lib/firmware/
    install -m 0644 ${S}/stream_options_6E3E00EFB74FE7D465FA88A171B81B8F.txt ${D}/lib/firmware/
    
    install -d ${D}${bindir}
    install -m 0755 ${S}/adrv-firmware.sh ${D}${bindir}/adrv-firmware.sh
}

FILES:${PN} += "/lib/firmware/*"
