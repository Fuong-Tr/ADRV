FSM_TIMEOUT=35
POLL_SEC=1

print_status()
{
    STATE=$(cat "$ADRV_DEV/jesd204_fsm_state" 2>/dev/null)
    ERROR=$(cat "$ADRV_DEV/jesd204_fsm_error" 2>/dev/null)
    echo "STATE = [$STATE], ERROR = [$ERROR]"
}

show_failure()
{
    echo
    echo "ERROR: JESD FSM did not reach opt_post_running_stage"
    print_status
    echo "--KERNEL LOG OF THIS RESET--"
    dmesg | tail -n 160

    case "$ERROR" in
        -14)
            echo "HINT: ADRV9029 CPU is stuck in Powerup mode."
            echo "Do not run adrv-firmware.sh repeatedly."
            echo "Run a full re-init: power cycle (or rmmod), then si5518config, then run this script once."
            ;;
        -1)
            echo "HINT: JESD RX link failed (often CGS). Check JESD RX clock/lane/reset timing."
            ;;
        -5)
            echo "HINT: Clock/JESD lane clock was not enabled. Verify Si5518 clock output and QPLL lock."
            ;;
    esac

    exit 2
}

echo "--Loading Kernel Modules--"
for MOD in dma-axi-dmac xilinx_transceiver axi_adxcvr_drv axi_jesd204_tx axi_jesd204_rx adrv9025_custom; do
    if ! modprobe "$MOD"; then
        echo "ERROR: modprobe $MOD failed"
        exit 1
    fi
done

sleep 5

echo "--Finding ADRV9029--"
ADRV_DEV=$(for d in /sys/bus/iio/devices/iio:device*; do
    if [ -f "$d/name" ] && [ "$(cat "$d/name" 2>/dev/null)" = "adrv9029" ]; then
        echo "$d"
        break
    fi
done)

if [ -z "$ADRV_DEV" ]; then
    echo "ERROR: Cannot find ADRV9029 IIO device"
    echo "Available IIO devices:"
    for d in /sys/bus/iio/devices/iio:device*; do
        echo "$d: $(cat "$d/name" 2>/dev/null)"
    done
    exit 1
fi

if [ ! -w "$ADRV_DEV/jesd204_fsm_ctrl" ]; then
    echo "ERROR: JESD FSM control attribute is unavailable: $ADRV_DEV/jesd204_fsm_ctrl"
    exit 1
fi

echo "ADRV_DEV = $ADRV_DEV"
echo "NAME     = $(cat "$ADRV_DEV/name")"
print_status

if [ "$STATE" = "opt_post_running_stage" ] && [ "$ERROR" = "0" ]; then
    echo "FSM DONE: already running"
    exit 0
fi

echo "--CLEARING OLD KERNEL LOG--"
dmesg -c > /dev/null 2>&1 || true

echo "--RESETTING JESD FSM ONCE--"
if ! echo 1 > "$ADRV_DEV/jesd204_fsm_ctrl"; then
    echo "ERROR: write to jesd204_fsm_ctrl failed"
    show_failure
fi

# The original script waited only 2 seconds. The ADRV9029 setup can take
# about 10-20 seconds, so wait until its final state or timeout.
ELAPSED=0
while [ "$ELAPSED" -lt "$FSM_TIMEOUT" ]; do
    sleep "$POLL_SEC"
    ELAPSED=$((ELAPSED + POLL_SEC))

    STATE=$(cat "$ADRV_DEV/jesd204_fsm_state" 2>/dev/null)
    ERROR=$(cat "$ADRV_DEV/jesd204_fsm_error" 2>/dev/null)
    echo "t=${ELAPSED}s: STATE=[$STATE], ERROR=[$ERROR]"

    if [ "$STATE" = "opt_post_running_stage" ] && [ "$ERROR" = "0" ]; then
        echo "--DONE SETUP--"
        exit 0
    fi

    # A failed FSM returns to idle. Wait a few seconds so the initial
    # idle state directly after issuing the reset is not misclassified.
    if [ "$ELAPSED" -ge 5 ] && [ "$STATE" = "idle" ] && \
       [ -n "$ERROR" ] && [ "$ERROR" != "0" ]; then
        show_failure
    fi
done

show_failure
