#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>

#define DAC_BASE          0x84A04000UL
#define DAC_MAP_SIZE      0x10000UL
#define DAC_RSTN_OFF      0x040UL

#define DAC_CH_BASE       0x400UL
#define DAC_CH_STRIDE     0x040UL
#define DAC_CH_CNTRL7     0x018UL
#define DAC_CH_USR3       0x020UL

#define DATA_SEL_DDS      0x0
#define DATA_SEL_DMA      0x2
#define NUM_DAC_CHANNELS  8

#define DMAC_BASE         0x9C420000UL
#define DMAC_MAP_SIZE     0x10000UL

#define DMAC_REG_CTRL             0x400UL
#define DMAC_REG_TRANSFER_ID      0x404UL
#define DMAC_REG_START_TRANSFER   0x408UL
#define DMAC_REG_FLAGS            0x40CUL
#define DMAC_REG_DEST_ADDRESS     0x410UL
#define DMAC_REG_SRC_ADDRESS      0x414UL
#define DMAC_REG_X_LENGTH         0x418UL
#define DMAC_REG_Y_LENGTH         0x41CUL
#define DMAC_REG_DEST_STRIDE      0x420UL
#define DMAC_REG_SRC_STRIDE       0x424UL
#define DMAC_REG_TRANSFER_DONE    0x428UL
#define DMAC_REG_IRQ_MASK         0x080UL

#define DMAC_CTRL_ENABLE          0x1
#define DMAC_FLAGS_CYCLIC         0x1

#define TXBUF_BASE        0x60000000UL
#define TXBUF_SIZE        0x01000000UL   
#define FRAME_BYTES       16UL           
#define LAST_SIZE_FILE    "/tmp/tx-dma.size"

#define RF_GPIO_BASE      0x80020000UL
#define RF_GPIO_MAP_SIZE  0x10000UL
#define RF_GPIO_DATA_OFF  0x000UL
#define RF_GPIO_VALUE_ON  0x000FFF0FUL
#define RF_GPIO_VALUE_OFF 0x00000000UL

static uint32_t rd32(volatile uint8_t *base, unsigned long off) {
    return *(volatile uint32_t *)(base + off);
}

static void wr32(volatile uint8_t *base, unsigned long off, uint32_t val) {
    *(volatile uint32_t *)(base + off) = val;
}

static unsigned long dac_ch_cntrl7_off(unsigned int ch) {
    return DAC_CH_BASE + (ch * DAC_CH_STRIDE) + DAC_CH_CNTRL7;
}

static void *map_phys(int fd, unsigned long phys, unsigned long size) {
    void *p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, phys);
    if (p == MAP_FAILED) {
        fprintf(stderr, "mmap 0x%lx failed: %s\n", phys, strerror(errno));
        return NULL;
    }
    return p;
}

static int open_mem(void) {
    int fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd < 0)
        fprintf(stderr, "open /dev/mem failed: %s\n", strerror(errno));
    return fd;
}

static void dump_dac(volatile uint8_t *dac) {} 
static void dump_dmac(volatile uint8_t *dmac) {}
static void dump_rf(volatile uint8_t *rf) {}

static int save_last_size(unsigned long size_bytes) {
    FILE *sf = fopen(LAST_SIZE_FILE, "w");
    if (!sf) {
        fprintf(stderr, "Can't Write %s: %s\n", LAST_SIZE_FILE, strerror(errno));
        return 1;
    }

    fprintf(sf, "%lu\n", size_bytes);
    fclose(sf);
    return 0;
}

static unsigned long read_last_size(void) {
    FILE *sf = fopen(LAST_SIZE_FILE, "r");
    unsigned long size_bytes = 0;

    if (!sf)
        return 0;

    if (fscanf(sf, "%lu", &size_bytes) != 1)
        size_bytes = 0;

    fclose(sf);
    return size_bytes;
}

static int validate_wave_size(unsigned long size_bytes) {
    if (size_bytes == 0) {
        fprintf(stderr, "Size waveform = 0. Need tx-dma load <file.bin>.\n");
        return 1;
    }

    if (size_bytes > TXBUF_SIZE) {
        fprintf(stderr, "Size waveform %lu overflow TXBUF_SIZE %lu.\n", size_bytes, TXBUF_SIZE);
        return 1;
    }

    if (size_bytes % FRAME_BYTES) {
        fprintf(stderr, "Size waveform %lu wrong FRAME_BYTES=%lu.\n", size_bytes, FRAME_BYTES);
        return 1;
    }

    return 0;
}

static int map_dac(int fd, volatile uint8_t **dac) {
    *dac = map_phys(fd, DAC_BASE, DAC_MAP_SIZE);
    return *dac ? 0 : 1;
}

static int map_dmac(int fd, volatile uint8_t **dmac) {
    *dmac = map_phys(fd, DMAC_BASE, DMAC_MAP_SIZE);
    return *dmac ? 0 : 1;
}

static int map_rf(int fd, volatile uint8_t **rf) {
    *rf = map_phys(fd, RF_GPIO_BASE, RF_GPIO_MAP_SIZE);
    return *rf ? 0 : 1;
}

static int set_all_dac_datasel(volatile uint8_t *dac, uint32_t val) {
    for (unsigned int ch = 0; ch < NUM_DAC_CHANNELS; ch++) {
        wr32(dac, dac_ch_cntrl7_off(ch), val);
    }
    usleep(1000);
    return 0;
}

static int cmd_load(const char *path) {
    int f = open(path, O_RDONLY);
    if (f < 0) {
        fprintf(stderr, "open %s failed: %s\n", path, strerror(errno));
        return 1;
    }

    struct stat st;
    if (fstat(f, &st) < 0) {
        fprintf(stderr, "fstat %s failed: %s\n", path, strerror(errno));
        close(f);
        return 1;
    }

    if (st.st_size <= 0) {
        fprintf(stderr, "File Erro: %s\n", path);
        close(f);
        return 1;
    }

    if ((unsigned long)st.st_size > TXBUF_SIZE) {
        fprintf(stderr, "Overflow: %ld bytes, TXBUF_SIZE=%lu bytes\n", (long)st.st_size, TXBUF_SIZE);
        close(f);
        return 1;
    }

    if (((unsigned long)st.st_size) % FRAME_BYTES) {
        fprintf(stderr, "File size %ld wrong FRAME_BYTES=%lu\n", (long)st.st_size, FRAME_BYTES);
        close(f);
        return 1;
    }

    int mem = open_mem();
    if (mem < 0) { close(f); return 1; }

    volatile uint8_t *buf = map_phys(mem, TXBUF_BASE, TXBUF_SIZE);
    if (!buf) { close(mem); close(f); return 1; }

    size_t total = 0;
    while (total < (size_t)st.st_size) {
        ssize_t n = read(f, (void *)(buf + total), (size_t)st.st_size - total);
        if (n < 0) {
            fprintf(stderr, "read %s failed: %s\n", path, strerror(errno));
            munmap((void *)buf, TXBUF_SIZE);
            close(mem);
            close(f);
            return 1;
        }
        if (n == 0)
            break;
        total += (size_t)n;
    }

    if (total != (size_t)st.st_size) {
        fprintf(stderr, "Load %zu/%ld bytes.\n", total, (long)st.st_size);
        munmap((void *)buf, TXBUF_SIZE);
        close(mem);
        close(f);
        return 1;
    }

    __sync_synchronize();
    msync((void *)buf, total, MS_SYNC);

    if (save_last_size((unsigned long)total)) {
        munmap((void *)buf, TXBUF_SIZE);
        close(mem);
        close(f);
        return 1;
    }

    printf("=> Load %zu bytes (0x%08lx)\n", total, TXBUF_BASE);
    printf("=> Save %s: %zu bytes\n", LAST_SIZE_FILE, total);
    munmap((void *)buf, TXBUF_SIZE);
    close(mem); close(f);
    return 0;
}

static int cmd_start(unsigned long size_bytes) {
    if (validate_wave_size(size_bytes))
        return 1;

    int fd = open_mem();
    if (fd < 0) return 1;

    volatile uint8_t *dac = NULL, *dmac = NULL, *rf = NULL;
    if (map_dac(fd, &dac) || map_dmac(fd, &dmac) || map_rf(fd, &rf)) return 1;

    printf("1. Turn off DDS ...\n");
    system("for i in $(seq 0 15); do iio_attr -o -c iio:device3 altvoltage$i raw 0 2>/dev/null; done");

    printf("2. RF PA on...\n");
    wr32(rf, RF_GPIO_DATA_OFF, RF_GPIO_VALUE_ON);
    usleep(1000);

    set_all_dac_datasel(dac, DATA_SEL_DMA);

    printf("3. AXI-DMAC...\n");
    wr32(dmac, DMAC_REG_CTRL, 0x0);
    usleep(1000);

    wr32(dmac, DMAC_REG_IRQ_MASK, 0x0);

    wr32(dmac, DMAC_REG_FLAGS, DMAC_FLAGS_CYCLIC);
    wr32(dmac, DMAC_REG_DEST_ADDRESS, 0x0);
    wr32(dmac, DMAC_REG_SRC_ADDRESS, (uint32_t)TXBUF_BASE);
    wr32(dmac, DMAC_REG_X_LENGTH, (uint32_t)(size_bytes - 1));
    wr32(dmac, DMAC_REG_Y_LENGTH, 0x0);
    wr32(dmac, DMAC_REG_DEST_STRIDE, 0x0);
    wr32(dmac, DMAC_REG_SRC_STRIDE, 0x0);

    __sync_synchronize();

    wr32(dmac, DMAC_REG_CTRL, DMAC_CTRL_ENABLE);
    usleep(1000);
    wr32(dmac, DMAC_REG_START_TRANSFER, 0x1);

    printf("\n==========================================\n");
    printf("=> CYCLIC MODE\n");
    printf("=> Size: %lu bytes\n", size_bytes);
    printf("==========================================\n");

    munmap((void *)dac, DAC_MAP_SIZE);
    munmap((void *)dmac, DMAC_MAP_SIZE);
    munmap((void *)rf, RF_GPIO_MAP_SIZE);
    close(fd);
    return 0;
}

static int cmd_stop(void) {
    int fd = open_mem();
    if (fd < 0) return 1;
    volatile uint8_t *dmac = NULL, *rf = NULL;
    if (!map_dmac(fd, &dmac)) {
        wr32(dmac, DMAC_REG_CTRL, 0x0); // Dung DMA
        munmap((void *)dmac, DMAC_MAP_SIZE);
    }
    if (!map_rf(fd, &rf)) {
        wr32(rf, RF_GPIO_DATA_OFF, RF_GPIO_VALUE_OFF); // Tat PA
        munmap((void *)rf, RF_GPIO_MAP_SIZE);
    }
    close(fd);
    printf("=> STOP.\n");
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Load: %s <file.bin>\n         %s start [size]\n         %s stop\n", argv[0], argv[0], argv[0]);
        return 1;
    }
    if (strcmp(argv[1], "load") == 0 && argc >= 3) return cmd_load(argv[2]);
    if (strcmp(argv[1], "start") == 0) {
        unsigned long size = 0;
        if (argc >= 3) {
            size = strtoul(argv[2], NULL, 0);
        } else {
            size = read_last_size();
            if (size == 0) {
                fprintf(stderr, "Load %s <file.bin> . OR %s start <size>.\n", argv[0], argv[0]);
                return 1;
            }
            printf("=> Old file size %s: %lu bytes\n", LAST_SIZE_FILE, size);
        }
        return cmd_start(size);
    }
    if (strcmp(argv[1], "stop") == 0) return cmd_stop();

    printf("Erro syntax. Use: %s load <file.bin> | start [size] | stop\n", argv[0]);
    return 1;
}
