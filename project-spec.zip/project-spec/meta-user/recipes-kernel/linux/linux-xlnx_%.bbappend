FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}:"

SRC_URI:append = " file://bsp.cfg"
KERNEL_FEATURES:append = " bsp.cfg"
SRC_URI += "file://user_2026-05-06-02-53-00.cfg \
            file://user_2026-05-06-08-12-00.cfg \
            file://user_2026-05-06-08-24-00.cfg \
            file://user_2026-05-22-04-47-00.cfg \
            file://user_2026-06-29-09-01-00.cfg \
            file://user_2026-06-30-04-04-00.cfg \
            "

